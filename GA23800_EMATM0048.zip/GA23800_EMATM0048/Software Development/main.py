"""
Author: Rory Owen Bennett
Section: Simulation
Description: This script runs a text-based coffee shop simulation, allowing the user to manage the 
shop's operations, including hiring and firing baristas, selling coffee, managing inventory, and handling finances.
"""

from coffee_shop import CoffeeShop, Coffee

def main():
    """
    Main function to run the coffee shop simulation. It initialises the coffee shop, allows the user to
    manage baristas, sell coffee, and updates the shop's status over a given number of months.
    """
    try:
        # Initialise the coffee shop
        shop = CoffeeShop("If It Makes You Feel Something")

        # Define the types of coffee sold in the shop
        coffee_types = [
            Coffee("Espresso", 0.0, 8, 0, 3, 1.5, 500),
            Coffee("Americano", 0.0, 6, 0, 2, 2.5, 200),
            Coffee("Filter", 0.0, 4, 0, 1, 1.5, 300),
            Coffee("Macchiato", 100, 8, 2, 4, 3.0, 400),
            Coffee("Flat White", 200, 8, 1, 5, 3.5, 600),
            Coffee("Latte", 300, 8, 3, 6, 4.0, 1000)
        ]
        coffee_names = [coffee.name for coffee in coffee_types]

        # Prompt the user for the number of months to run the simulation
        while True:
            try:
                months = int(input(">>> Please enter number of months (1-6): ") or 6)
                if 1 <= months <= 6:
                    break
                else:
                    print("Number of months must be between 1 and 6.")
            except ValueError as e:
                print(f"Invalid input for months: {e}")

        # Run the simulation for the specified number of months
        for month in range(1, months + 1):
            print(f"\n====== SIMULATING month {month} ======")

            # Manage baristas
            while True:
                try:
                    current_baristas = len(shop.baristas)
                    baristas_change = int(input(f"Enter number of baristas to add/remove (current: {current_baristas}, positive to add, negative to remove, 0 for no change): "))
                    if current_baristas + baristas_change < 1:
                        print("You must have at least one barista.")
                    elif current_baristas + baristas_change > 4:
                        print("You cannot have more than 4 baristas.")
                    else:
                        break
                except ValueError:
                    print("Invalid input. Please enter an integer.")

            if baristas_change > 0:
                for _ in range(baristas_change):
                    name = input("Enter barista name: ").strip()
                    while True:
                        specialty = input(f"Enter barista specialty (choose from {coffee_names}, leave blank if none): ").strip()
                        if specialty == "" or specialty in coffee_names:
                            break
                        else:
                            print(f"Invalid specialty. Please choose from {coffee_names}.")
                    shop.add_barista(name, specialty)
            elif baristas_change < 0:
                for _ in range(-baristas_change):
                    name = input("Enter barista name to remove: ").strip()
                    shop.remove_barista(name)

            # Sell coffee
            for coffee in coffee_types:
                while True:
                    try:
                        sell_amount = int(input(f"Coffee {coffee.name}, demand {coffee.demand}, how much to sell: "))
                        if sell_amount < 0 or sell_amount > coffee.demand:
                            raise ValueError(f"Sell amount must be a non-negative integer less than or equal to {coffee.demand}.")
                        
                        milk, beans, spices = coffee.get_ingredients()
                        required_labour_hours = coffee.prep_time * sell_amount / 60

                        # Check if there are enough labour hours available
                        if shop.available_labour_hours < required_labour_hours:
                            print(f"Insufficient labour: quantity requested {sell_amount}, capacity {int(shop.available_labour_hours * 60 / coffee.prep_time)}")
                            raise ValueError("Insufficient labour hours.")
                        
                        # Check if there are enough ingredients available
                        if not shop.check_inventory(milk * sell_amount, beans * sell_amount, spices * sell_amount):
                            print("Insufficient ingredients:")
                            if milk * sell_amount > shop.ingredients['milk']:
                                print(f"Milk need {milk * sell_amount}, pantry {shop.ingredients['milk']}")
                            if beans * sell_amount > shop.ingredients['beans']:
                                print(f"Beans need {beans * sell_amount}, pantry {shop.ingredients['beans']}")
                            if spices * sell_amount > shop.ingredients['spices']:
                                print(f"Spices need {spices * sell_amount}, pantry {shop.ingredients['spices']}")
                            raise ValueError("Insufficient ingredients.")
                        
                        break
                    except ValueError as e:
                        print(f"Invalid input for sell amount: {e}")
                
                # Update inventory and cash if sell amount is greater than or equal to 0
                if sell_amount > 0:
                    shop.update_inventory(milk * sell_amount, beans * sell_amount, spices * sell_amount)
                    shop.cash += coffee.price * sell_amount
                    shop.available_labour_hours -= required_labour_hours
                    print(f"Sold {sell_amount} units of {coffee.name}. Shop cash balance at {shop.cash:.2f}")

            # Pay expenses
            total_wages = sum([barista.get_monthly_wage() for barista in shop.baristas])
            pantry_costs = sum([shop.ingredients[ingredient] * shop.pantry_costs[ingredient] for ingredient in shop.ingredients])
            total_expenses = total_wages + shop.rent + pantry_costs
            if not shop.pay_expenses():
                # Apply depreciation to the inventory
                shop.apply_depreciation()
                
                print(f"\n=== {shop.name} - End of Month {month} Expenses ===")
                print(f"Rent/Utilities: {shop.rent}")
                print(f"Total Pantry Costs: {pantry_costs}")
                for ingredient, cost in shop.pantry_costs.items():
                    print(f"{ingredient.capitalize()}: {shop.ingredients[ingredient] * cost:.2f}")
                print(f"Total Wages: {total_wages}")
                for barista in shop.baristas:
                   print(f"{barista.name}, hourly rate={barista.hourly_rate}, amount={barista.hourly_rate * barista.monthly_hours}")
                
                final_cash = shop.cash - total_expenses
                print(f"\n=== {shop.name} - Final State Month {month} ===")
                print(f"Cash: {final_cash:.2f}")
                print("Pantry:")
                for ingredient, amount in shop.ingredients.items():
                    print(f"{ingredient.capitalize()}, {amount} (capacity={shop.max_ingredients[ingredient]})")
                print("Baristas:")
                for barista in shop.baristas:
                    print(f"{barista.name}, hourly rate={barista.hourly_rate}, amount={barista.hourly_rate * barista.monthly_hours}")
                print(f"\nWent bankrupt paying expenses in month {month}.")
                break

            # Print end of month summary
            print(f"\n=== {shop.name} - End of Month {month} Expenses ===")
            print(f"Paid Rent/Utilities: {shop.rent}")
            print(f"Paid Total Pantry Costs: {pantry_costs}")
            for ingredient, cost in shop.pantry_costs.items():
                print(f"{ingredient.capitalize()}: {shop.ingredients[ingredient] * cost:.2f}")
            print(f"Paid Total Wages: {total_wages}")
            for barista in shop.baristas:
               print(f"{barista.name}, hourly rate={barista.hourly_rate}, amount={barista.hourly_rate * barista.monthly_hours}")
            
            print(f"\n=== {shop.name} - Summary Statement ===")
            print(f"Cash: {shop.cash:.2f}")
            print("Pantry:")
            for ingredient, amount in shop.ingredients.items():
                print(f"{ingredient.capitalize()}, {amount} (capacity={shop.max_ingredients[ingredient]})")
            print("Baristas:")
            for barista in shop.baristas:
                print(f"{barista.name}, hourly rate={barista.hourly_rate}, amount={barista.hourly_rate * barista.monthly_hours}")

            # Apply depreciation to the inventory
            shop.apply_depreciation()

            # Replenish inventory
            if not shop.replenish_inventory():
                print("Replenishing Inventory")
                print("Went bankrupt. Simulation ends.")
                break

            # Reset labour hours for the next month
            shop.reset_labour_hours()

    except Exception as e:
        print(f"An unexpected error occurred: {e}")

if __name__ == "__main__":
    main()    