"""
Author: Rory Owen Bennett
Section: Classes
Description: This script defines the classes required for a text-based coffee shop simulation. 
It includes the CoffeeShop, Barista, and Coffee classes, which manage the shop's operations, 
employees, and coffee types, respectively.
"""

class CoffeeShop:
    """
    The CoffeeShop class manages the operations of the coffee shop, including finances, inventory, 
    and employees.

    Attributes:
        name (str): The name of the coffee shop.
        cash (float): The current cash balance of the coffee shop.
        rent (float): The fixed monthly rent cost.
        baristas (list): A list of Barista objects representing the employees.
        max_ingredients (dict): The maximum storage capacity for each ingredient.
        ingredients (dict): The current inventory of ingredients.
        pantry_costs (dict): The cost to store each unit of ingredients.
        depreciation (dict): The depreciation rate for each ingredient.
        supplier_costs (dict): The cost to purchase each unit of ingredients from the supplier.
        total_labour_hours (int): The total labour hours available from all baristas.
        available_labour_hours (int): The current available labour hours.
    """
    def __init__(self, name):
        """
        Initialises the CoffeeShop with the given name, initial cash, rent, and ingredient settings.
        """
        self.name = name
        self.cash = 10000  # Initial cash balance
        self.rent = 1500
        self.baristas = []
        
        # Define maximum and initial ingredient levels
        self.max_ingredients = {
            'milk': 300000, # MilliLiters
            'beans': 20000, # Grams
            'spices': 4000  # Grams
        }
        self.ingredients = {
            'milk': 300000, # MilliLiters
            'beans': 20000, # Grams
            'spices': 4000  # Grams
        }
        self.pantry_costs = {
            'milk': 0.0001,
            'beans': 0.001,
            'spices': 0.001
        }
        self.depreciation = {
            'milk': 0.4,
            'beans': 0.1,
            'spices': 0.1
        }
        self.supplier_costs = {
            'milk': 0.0003,
            'beans': 0.10,
            'spices': 0.05
        }
        self.total_labour_hours = 0
        self.available_labour_hours = 0

    def add_barista(self, name, specialty=None):
        """
        Adds a barista to the coffee shop if the maximum number of baristas (4) is not exceeded.

        Parameters:
            name (str): The name of the barista.
            specialty (str, optional): The specialty of the barista, if any.
        """
        if len(self.baristas) < 4:
            self.baristas.append(Barista(name, specialty))
            self.total_labour_hours += 80
            self.available_labour_hours += 80
        else:
            print("Cannot add more than 4 baristas.")

    def remove_barista(self, name):
        """
        Removes a barista from the coffee shop by name.

        Parameters:
            name (str): The name of the barista to remove.
        """
        for barista in self.baristas:
            if barista.name == name:
                self.baristas.remove(barista)
                self.total_labour_hours -= 80
                self.available_labour_hours -= 80
                return
        print("Barista not found.")

    def check_inventory(self, milk, beans, spices):
        """
        Checks if the coffee shop has enough ingredients to make a certain amount of coffee.

        Parameters:
            milk (float): The amount of milk required.
            beans (float): The amount of beans required.
            spices (float): The amount of spices required.

        Returns:
            bool: True if there are enough ingredients, False otherwise.
        """
        return self.ingredients['milk'] >= milk and self.ingredients['beans'] >= beans and self.ingredients['spices'] >= spices

    def update_inventory(self, milk, beans, spices):
        """
        Updates the inventory by subtracting the used amounts of milk, beans, and spices.

        Parameters:
            milk (float): The amount of milk used.
            beans (float): The amount of beans used.
            spices (float): The amount of spices used.
        """
        self.ingredients['milk'] -= milk
        self.ingredients['beans'] -= beans
        self.ingredients['spices'] -= spices

    def replenish_inventory(self):
        """
        Replenishes the inventory to its maximum capacity if there is enough cash to cover the cost.

        Returns:
            bool: True if the inventory was replenished, False if there was insufficient cash.
        """
        for ingredient in self.ingredients:
            cost = (self.max_ingredients[ingredient] - self.ingredients[ingredient]) * self.supplier_costs[ingredient]
            if self.cash >= cost:
                self.cash -= cost
                self.ingredients[ingredient] = self.max_ingredients[ingredient]
            else:
                print(f"Can't restock {ingredient.capitalize()}, insufficient funds, need {cost} but only have {self.cash}")
                return False
        return True

    def apply_depreciation(self):
        """
        Applies depreciation to the inventory, reducing the amounts based on the depreciation rate.
        """
        for ingredient in self.ingredients:
            self.ingredients[ingredient] -= int(self.ingredients[ingredient] * self.depreciation[ingredient])

    def pay_expenses(self):
        """
        Pays the monthly expenses, including wages, rent, and pantry costs. 

        Returns:
            bool: True if there was enough cash to cover the expenses, False otherwise.
        """
        total_wages = sum([barista.get_monthly_wage() for barista in self.baristas])
        pantry_costs = sum([self.ingredients[ingredient] * self.pantry_costs[ingredient] for ingredient in self.ingredients])
        
        total_expenses = total_wages + self.rent + pantry_costs
        
        if self.cash >= total_expenses:
            self.cash -= total_expenses
            return True
        return False

    def reset_labour_hours(self):
        """
        Resets the available labour hours to the total labour hours at the start of a new month.
        """
        self.available_labour_hours = self.total_labour_hours

class Barista:
    """
    The Barista class represents an employee of the coffee shop.

    Attributes:
        name (str): The name of the barista.
        specialty (str): The specialty of the barista, if any.
        hourly_rate (float): The hourly wage of the barista.
        monthly_hours (int): The total number of hours worked per month.
        available_hours (int): The current available working hours for the month.
    """
    def __init__(self, name, specialty=None):
        """
        Initialises a Barista with the given name, specialty, hourly rate, and monthly hours.
        """
        self.name = name
        self.specialty = specialty
        self.hourly_rate = 15
        self.monthly_hours = 120
        self.available_hours = 80

    def get_monthly_wage(self):
        """
        Calculates the monthly wage for the barista.

        Returns:
            float: The monthly wage.
        """
        return self.hourly_rate * self.monthly_hours
    
class Coffee:
    """
    The Coffee class represents a type of coffee sold in the coffee shop.

    Attributes:
        name (str): The name of the coffee.
        milk (float): The amount of milk required per unit.
        beans (float): The amount of beans required per unit.
        spices (float): The amount of spices required per unit.
        prep_time (float): The time required to prepare one unit of coffee.
        price (float): The selling price of one unit of coffee.
        demand (int): The monthly demand for the coffee.
    """
    def __init__(self, name, milk, beans, spices, prep_time, price, demand):
        """
        Initialises a Coffee with the given attributes.
        """
        self.name = name
        self.milk = milk
        self.beans = beans
        self.spices = spices
        self.prep_time = prep_time
        self.price = price
        self.demand = demand

    def get_ingredients(self):
        """
        Returns the amounts of milk, beans, and spices required for one unit of coffee.

        Returns:
            tuple: A tuple containing the amounts of milk, beans, and spices.
        """
        return self.milk, self.beans, self.spices