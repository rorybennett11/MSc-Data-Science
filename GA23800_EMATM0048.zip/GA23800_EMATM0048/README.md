# GA23800_EMATM0048 - Software Development: Programming and Algorithms Coursework

# Part 1: Software Development - Coffee Shop Simulation

## Description
For this project, I used Python to implement a text-based simulation of a coffee shop. It allows users to operate a fictional coffee shop over a specified number of months. The user can hire and fire baristas, sell different types of coffee, manage the shop's inventory, and handle it's finances. The primary goal is to keep the coffee shop in profit and avoid bankruptcy.

## Project Structure
The project is divided between two files:
- `coffee_shop.py`: This script contains the implementation of the core classes (`CoffeeShop`, `Barista`, and `Coffee`) that form the basis for managing the shop's operations.
- `main.py`: This is the script that runs the simulation, allowing the user to interact with the coffee shop by hiring baristas, selling coffee, and managing it's resources.

### coffee_shop.py
This file defines three key classes:

#### CoffeeShop
The `CoffeeShop` class manages the overall operations of the coffee shop, including finances, inventory, and employees. 

**Attributes:**
- `name`: The name of the coffee shop.
- `cash`: The current cash balance of the coffee shop.
- `rent`: The fixed monthly rent cost.
- `baristas`: A list of `Barista` objects representing the employees.
- `max_ingredients`: The maximum storage capacity for each ingredient.
- `ingredients`: The current inventory of ingredients.
- `pantry_costs`: The cost to store each unit of ingredients.
- `depreciation`: The depreciation rate for each ingredient.
- `supplier_costs`: The cost to purchase each unit of ingredients from the supplier.
- `total_labour_hours`: The total labour hours available from all baristas.
- `available_labour_hours`: The current available labour hours.

**Methods:**
- `__init__(self, name)`: Initialises the `CoffeeShop` with a given name and default values for cash, rent, ingredients, and other attributes.
- `add_barista(self, name, specialty=None)`: Adds a barista to the coffee shop by name.
- `remove_barista(self, name)`: Removes a barista from the coffee shop by name.
- `check_inventory(self, milk, beans, spices)`: Checks if the shop has enough ingredients to make a certain amount of coffee.
- `update_inventory(self, milk, beans, spices)`: Updates the inventory by subtracting the amount of milk, beans, and spices which are used.
- `replenish_inventory(self)`: Replenishes the inventory to its maximum capacity if there is enough cash.
- `apply_depreciation(self)`: Applies depreciation to the inventory, reducing the amount of each ingredient based on the depreciation rate.
- `pay_expenses(self)`: Pays the monthly expenses, including wages, rent, and pantry costs.
- `display_status(self)`: Displays the current status of the coffee shop, including cash balance, pantry levels, and baristas.
- `reset_labour_hours(self)`: Resets the available labour hours to the total labor hours at the start of a new month.

#### Barista
The `Barista` class represents an employee of the coffee shop.

**Attributes:**
- `name`: The name of the barista.
- `specialty`: The specialty of the barista, if any.
- `hourly_rate`: The hourly wage of the barista.
- `monthly_hours`: The total number of hours worked per month.
- `available_hours`: The current available working hours for the month.

**Methods:**
- `__init__(self, name, specialty=None)`: Initialises a `Barista` with a given name, specialty, hourly rate, and monthly hours.
- `get_monthly_wage(self)`: Calculates the monthly wage for the barista.

#### Coffee
The `Coffee` class represents a type of coffee sold in the coffee shop.

**Attributes:**
- `name`: The name of the coffee.
- `milk`: The amount of milk required per unit of coffee.
- `beans`: The amount of beans required per unit of coffee.
- `spices`: The amount of spices required per unit of coffee.
- `prep_time`: The time required to prepare one unit of coffee.
- `price`: The selling price of one unit of coffee.
- `demand`: The monthly demand for the coffee.

**Methods:**
- `__init__(self, name, milk, beans, spices, prep_time, price, demand)`: Initialises a `Coffee` with the given attributes.
- `get_ingredients(self)`: Returns the amounts of milk, beans, and spices required for one unit of coffee.

### main.py
The `main.py` script runs the coffee shop simulation, allowing the user to interact with it.

**Function:**
- `main()`: The main function to run the coffee shop simulation which initialises the coffee shop and allows the user to manage baristas and sell coffee. It also updates the shop's status over the chosen number of months.

### Design Choices
1. **Object-Oriented Design**: The project is designed using an object-oriented approach to enable the functionalities of the coffee shop, baristas, and coffee types within their individual classes. This design makes the code modular, easy to understand, and maintain.
2. **Separation of Concerns**: The `coffee_shop.py` file contains all the class definitions and business logic, while the `main.py` file handles user interaction and the simulation loop. This separation makes the code more organised and easier to manage.
3. **Error Handling**: The code includes basic error handling to manage scenarios such as adding more than the maximum allowed baristas, trying to remove a non-existent barista, and checking inventory before selling coffee.
4. **Simulation Flexibility**: The simulation can be run for a user-defined number of months, allowing for flexibility in testing and use.

### Conclusion
My coffee shop simulation demonstrates the use of object-oriented programming to model and manage real-world concepts and interactions. The design ensures that the code is modular, maintainable, and easy to understand, making it a valuable tool in my learning and practicing of Python programming concepts.

# Part 2 - Data Analytics - Weather Data Analysis

## Description

This part of the project uses Jupyter Notebook to perform exploratory data analysis on weather data obtained from various American cities. In my analysis, I computed basic statistics, visualised distributions, explored relationships between different weather variables, and built a linear regression model to predict atmospheric pressure based on temperature and humidity.

## Project Structure

### Prerequisites

To run the code for the analysis, you need the following libraries and tools installed:

1. **pandas**: For data manipulation and analysis.
2. **matplotlib**: For plotting graphs and visualizations.
3. **seaborn**: For advanced data visualization.
4. **scipy**: For scientific and technical computing, including statistical analysis.
5. **scikit-learn**: For machine learning, including linear regression and model evaluation.

You can install the required Python libraries using pip:

`!pip install pandas matplotlib seaborn scipy scikit-learn`

### Data Source
The weather data is obtained from the OpenWeather API. You will need an API key in order to fetch the data and this can be obtained by signing up at OpenWeather.

### Files
- weather_data.csv: The original weather data fetched from the OpenWeather API.
- enriched_weather_data.csv: The enriched dataset with additional features (temperature in Fahrenheit and categorised weather descriptions).
- SDPA Data Analytics.ipynb: The Jupyter Notebook script that performs the data analysis.

### Running the Analysis

1. **Fetch Weather Data**:
- Use the OpenWeather API to fetch the current weather data for a list of cities and save it to weather_data.csv.
- Ensure you have your personal API key and include it in the script for data fetching.

2. **Data Preparation and Cleaning**:
- Load the dataset into a Pandas DataFrame.
- Handle missing data and outliers.
- Enrich the dataset with additional features (temperature in Fahrenheit and categorised weather descriptions).

3. **Exploratory Data Analysis (EDA)**:
- Compute basic statistics for temperature, humidity, and pressure.
- Visualise distributions using histograms.
- Explore relationships between variables using scatter plots.
- Analyse the distribution of weather categories using bar charts.

4. **Statistical Analysis and Modeling**:
- Perform t-tests to compare temperature and humidity between different weather conditions.
- Calculate correlations between temperature, humidity, and pressure.
- Build a linear regression model to predict atmospheric pressure based on temperature and humidity.

### Conclusion

This weather data project provides a comprehensive analysis of weather data across various American cities, offering insights into their temperature, humidity, and pressure patterns. By leveraging additional data sources and advanced analytical techniques, future work can aim to further enhance our understanding of weather dynamics and their broader implications.
