'''Loading the necessary packages'''

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score
from sklearn.utils import resample
from sklearn.dummy import DummyClassifier

'''Brief exploration of the data'''

# Load the dataset
file_name = 'penguins.csv'
penguins = pd.read_csv(file_name)

# Drop unnecessary columns
penguins = penguins.drop(columns=['rowid', 'year'])

# Display basic information about the dataset
print(penguins.info())
print(penguins.describe())

# Check for missing values
print(penguins.isnull().sum())

# Visualize missing values
plt.figure(figsize=(10, 6))
sns.heatmap(penguins.isnull(), cbar=False, cmap='viridis')
plt.title('Heatmap of Missing Values')
plt.show()

# Handle missing values via simple imputation
penguins.fillna(penguins.mean(numeric_only=True), inplace=True)

# Visualise the distribution of numerical features
sns.pairplot(penguins.dropna(), hue='species')
plt.show()

'''Unsupervised Learning: K-Means Clustering'''

# Preprocess the data
features = ['bill_length_mm', 'bill_depth_mm', 'flipper_length_mm', 'body_mass_g']
X = penguins[features]
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Apply K-Means
kmeans = KMeans(n_clusters=3, n_init=10, random_state=42)
penguins['cluster'] = kmeans.fit_predict(X_scaled)

# Visualise the clusters
sns.pairplot(penguins, hue='cluster', vars=features)
plt.show()

# Compare with actual species
contingency_table = pd.crosstab(penguins['species'], penguins['cluster'])
print(contingency_table)

'''Classification Algorithm 1: k-Nearest Neighbours'''

# Encode the target labels
le = LabelEncoder()
penguins['species'] = le.fit_transform(penguins['species'])

# Handle class imbalance by upsampling minority classes
max_size = penguins['species'].value_counts().max()

# Separate classes
penguins_majority = penguins[penguins['species'] == 0]
penguins_minority_1 = penguins[penguins['species'] == 1]
penguins_minority_2 = penguins[penguins['species'] == 2]

# Upsample minority classes
penguins_minority_1_upsampled = resample(penguins_minority_1, 
                                         replace=True,     # sample with replacement
                                         n_samples=max_size,    # to match majority class
                                         random_state=42) # reproducible results

penguins_minority_2_upsampled = resample(penguins_minority_2, 
                                         replace=True,     # sample with replacement
                                         n_samples=max_size,    # to match majority class
                                         random_state=42) # reproducible results

# Combine majority class with upsampled minority classes
penguins_balanced = pd.concat([penguins_majority, penguins_minority_1_upsampled, penguins_minority_2_upsampled])

# Display new class counts
print(penguins_balanced['species'].value_counts())

# Split the data
X_train, X_test, y_train, y_test = train_test_split(penguins_balanced[features], penguins_balanced['species'], test_size=0.3, random_state=42)

# Train k-NN classifier
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train, y_train)

# Make predictions
y_pred_knn = knn.predict(X_test)

# Evaluate the model
print(classification_report(y_test, y_pred_knn, zero_division=0))
print("k-NN Accuracy:", accuracy_score(y_test, y_pred_knn))

'''Classification Algorithm 2: Random Forest'''

# Train Random Forest classifier
rf = RandomForestClassifier(n_estimators=100, random_state=42)
rf.fit(X_train, y_train)

# Make predictions
y_pred_rf = rf.predict(X_test)

# Evaluate the model
print(classification_report(y_test, y_pred_rf, zero_division=0))
print("Random Forest Accuracy:", accuracy_score(y_test, y_pred_rf))

'''Comparison and Baseline'''

# Baseline model
dummy = DummyClassifier(strategy='most_frequent')
dummy.fit(X_train, y_train)
y_pred_dummy = dummy.predict(X_test)

# Evaluate the baseline model
print(classification_report(y_test, y_pred_dummy, zero_division=0))
print("Baseline Accuracy:", accuracy_score(y_test, y_pred_dummy))

# Compare accuracies
print("Baseline Accuracy:", accuracy_score(y_test, y_pred_dummy))
print("k-NN Accuracy:", accuracy_score(y_test, y_pred_knn))
print("Random Forest Accuracy:", accuracy_score(y_test, y_pred_rf))


